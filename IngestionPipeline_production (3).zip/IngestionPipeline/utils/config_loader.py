"""config_loader.py — loads and validates config.yaml"""

import os
import yaml
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict



@dataclass
class GCPConfig:
    project_id: str
    location: str


@dataclass
class GCSConfig:
    input_bucket: str
    destination_bucket: str
    input_prefix: str
    parsed_prefix: str
    # Output prefixes used by PREVIOUS runs. Listed here so their JSON is
    # ignored as input when you switch parsed_prefix for a clean re-run.
    legacy_parsed_prefixes: List[str] = field(default_factory=list)
    # Consolidate outputs per OPP id: newest version in the main directory,
    # older versions under archive/. Off = mirror the input paths as-is.
    opp_grouping: bool = False
    # How to read the 8-digit stamp in Modified-File folder names.
    # DDMMYYYY: 05082026 = 5 Aug 2026 (Irish/European convention).
    opp_date_format: str = "DDMMYYYY"
    # Parse older versions of a document as well as the current one. Their
    # output goes straight to archive/, which nothing reads, so leaving this
    # off is the single biggest speed/cost saving.
    parse_superseded_versions: bool = False
    # Keep superseded document versions under <opp>/archive/. When false the
    # OPP folder holds ONLY the latest version of each document; a newer
    # Modified-File version overwrites the older output in place.
    opp_archive_versions: bool = False
    # Copy from a separate source bucket before parsing? New opportunity
    # folders now land directly in the destination bucket, so this is off.
    # Set true (and set source_bucket/source_prefix) to re-enable.
    sync_enabled: bool = False

    destination_project_id: str = ""
    source_bucket: str = ""
    source_prefix: str = ""
    source_project_id: str = ""


@dataclass
class GeminiConfig:
    model: str
    temperature: float
    max_output_tokens: int

@dataclass
class LLMConfig:
    project_id: str
    proxy_url: str

@dataclass
class ExcelConfig:
    max_cells_for_gemini: int = 4000


@dataclass
class ValidationConfig:
    # Run the quote-to-order validation agent after parsing each opportunity.
    enabled: bool = False
    # Agent calls are slow (LLM + BigQuery); keep concurrency low.
    max_workers: int = 2
    # Stop the run if the agent can't be loaded at all, instead of writing
    # an "agent_unavailable" verdict for every opportunity.
    fail_fast: bool = True
    # Re-validate an opportunity whenever its document set changes, even if
    # nothing needed parsing. This is what closes a failed check when the
    # missing document later arrives under Modified-File.
    revalidate_on_change: bool = True


@dataclass
class RuntimeConfig:
    # Stop taking new files after this many seconds so state can be persisted
    # before the Cloud Run Functions timeout (540s) hard-kills the process.
    max_runtime_seconds: int = 450
    # Parallel file workers (LLM calls are I/O-bound).
    max_workers: int = 4
    # After this many failed attempts a file is dead-lettered (status
    # "failed") and skipped until its content changes.
    max_file_attempts: int = 3
    # A crashed run's lock is stolen after this many seconds.
    lock_lease_seconds: int = 900
    # Minimum seconds between ledger writes. GCS caps object mutations at
    # ~1/second per object; fast batches otherwise trigger 429s.
    state_save_min_interval: float = 10.0
    # Reuse a parsed result when another file has byte-identical content
    # (same MD5). Modified-File uploads re-send unchanged documents
    # constantly, so this removes a large share of LLM calls.
    dedup_identical_files: bool = True


@dataclass
class SchedulerConfig:
    cron: str
    timezone: str

@dataclass
class PipelineConfig:
    gcp: GCPConfig
    gcs: GCSConfig
    llm: LLMConfig
    gemini: GeminiConfig
    excel: ExcelConfig
    runtime: RuntimeConfig
    validation: ValidationConfig
    scheduler: SchedulerConfig
    supported_extensions: Dict[str, List[str]]
    state_tracker_blob: str


_REQUIRED_SECTIONS = (
    "gcp", "gcs", "llm", "gemini", "scheduler", "supported_extensions", "state",
)

def load_config(config_path: str = None) -> PipelineConfig:
    """
    Load pipeline configuration from a YAML file.

    Priority order:
      1. Explicit path passed to this function
      2. CONFIG_PATH environment variable
      3. config.yaml next to this file
    """
    if config_path is None:
        config_path = os.environ.get(
            "CONFIG_PATH",
            str(Path(__file__).parent.parent / "config.yaml"),
        )

    with open(config_path, "r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)

    missing = [k for k in _REQUIRED_SECTIONS if k not in (raw or {})]
    if missing:
        raise ValueError(
            f"config.yaml is missing required section(s): {', '.join(missing)} "
            f"(loaded from {config_path})"
        )

    # Allow environment variables to override sensitive fields
    raw["gcp"]["project_id"] = os.environ.get(
        "GCP_PROJECT_ID", raw["gcp"]["project_id"]
    )
    raw["gcs"]["destination_bucket"] = os.environ.get(
        "GCS_DESTINATION_BUCKET",
        raw["gcs"].get("destination_bucket", raw["gcs"].get("input_bucket", "")),
    )
    raw["gcs"]["destination_project_id"] = os.environ.get(
        "GCS_DESTINATION_PROJECT_ID",
        raw["gcs"].get("destination_project_id", raw["gcp"]["project_id"]),
    )
    raw["gcs"]["input_bucket"] = raw["gcs"]["destination_bucket"]
    raw["gcs"]["source_bucket"] = os.environ.get(
        "GCS_SOURCE_BUCKET", raw["gcs"].get("source_bucket", "")
    )
    raw["gcs"]["source_prefix"] = os.environ.get(
        "GCS_SOURCE_PREFIX", raw["gcs"].get("source_prefix", "")
    )
    raw["gcs"]["source_project_id"] = os.environ.get(
        "GCS_SOURCE_PROJECT_ID", raw["gcs"].get("source_project_id", "")
    )
    raw["gemini"]["model"] = os.environ.get(
        "GEMINI_MODEL", raw["gemini"]["model"]
    )

    return PipelineConfig(
        gcp=GCPConfig(**raw["gcp"]),
        gcs=GCSConfig(**raw["gcs"]),
        llm=LLMConfig(**raw["llm"]),
        gemini=GeminiConfig(**raw["gemini"]),
        excel=ExcelConfig(**raw.get("excel", {})),
        runtime=RuntimeConfig(**raw.get("runtime", {})),
        validation=ValidationConfig(**raw.get("validation", {})),
        scheduler=SchedulerConfig(**raw["scheduler"]),
        supported_extensions=raw["supported_extensions"],
        state_tracker_blob=raw["state"]["tracker_blob"],
    )
