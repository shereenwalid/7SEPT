# VAL-Q2O-023

| Field | Value |
|---|---|
| **Validation Name** | Recurring Item Contract Term Validation |
| **Rule Description** | Ensure that where an order contains one or more recurring items, a customer Contract Term is specified in the Technical Specification. Recurring charges cannot be billed correctly without an agreed term. |
| **Pass Criteria** | 1. The order contains no recurring items — validation not applicable.<br>2. OR recurring items are present **and** the Contract Term field is present, populated, and contains a usable value (e.g. 12 / 24 / 36 Months). |
| **Validation Type** | Base |
| **Fail Action** | 1. Recurring items are present and the Contract Term field is missing.<br>2. Recurring items are present and the Contract Term field is empty, null, or contains no usable value. |
| **Status** | IN-REFINEMENT |

## Additional Comments

- An item is treated as **recurring** when any of the following is true:
  - the line item is marked `Recurring` in the Technical Specification
    (e.g. the *Once off / Recurring* column);
  - the **PO Type** is set to `Recurring` (see VAL-Q2O-022);
  - a **Billing Frequency** is specified that implies an ongoing charge
    (see VAL-Q2O-021), such as monthly, quarterly or annually.
- Relationship to existing validations:
  - **VAL-Q2O-013** requires a Contract Term unconditionally for every order.
    VAL-Q2O-023 is the *conditional* rule: it makes the requirement
    unambiguously blocking whenever recurring revenue is involved, and it
    names the offending line items so the gap can be closed quickly.
  - **VAL-Q2O-022** confirms the PO Type is `Recurring`. VAL-Q2O-023 then
    confirms the commercial term that must accompany it.
  - Where VAL-Q2O-013 and VAL-Q2O-023 both fail, the underlying fix is the
    same: populate the Contract Term in the Technical Specification.
- The validation output must list the recurring line items that triggered
  the rule, so Sales can see exactly what needs a term.
- Where the Contract Term is missing or blank and recurring items exist, the
  order cannot proceed until a valid Contract Term is provided.

## Example

**Pass (not applicable):** All line items marked `Once Off`; Contract Term
absent. → NA.

**Pass:** Line item *Managed Router — Recurring*; Contract Term = `36 Months`.
→ Y.

**Fail:** Line items *Managed Router — Recurring* and *Support — Recurring*;
Contract Term field empty in the Technical Specification. → N, with reasoning
naming both recurring items.

## Implementation notes

- Implemented in the validation agent as `VAL-023` within the `val_checks`
  output array.
- Verdicts are `Y` / `N` / `NA`. `NA` is used when the order has no recurring
  items, and is not counted as a failure.
- Action on failure: `raise_sales`.
