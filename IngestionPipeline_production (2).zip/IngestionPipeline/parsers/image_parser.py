"""
parsers/image_parser.py

Sends raw image bytes (PNG / JPEG / GIF / WEBP) to Gemini for structured
JSON extraction — no OCR library involved, the model reads the image
directly.
"""

import json
import logging
from typing import Dict, Any, Optional

from utils.gemini_client import GeminiClient, ImagesNotPermitted, GENERIC_JSON_PROMPT

logger = logging.getLogger(__name__)

# Gemini rejects oversized inline payloads (~20 MB total request), so refuse
# earlier with a clear message rather than letting the API return an opaque
# error after the whole upload.
MAX_IMAGE_BYTES = 18 * 1024 * 1024

# Content sniffing: a filename-derived MIME type is often wrong or missing
# (email attachments named "attachment", mislabeled files). Magic bytes are
# authoritative.
_MAGIC = (
    (b"\x89PNG\r\n\x1a\n", "image/png"),
    (b"\xff\xd8\xff", "image/jpeg"),
    (b"GIF87a", "image/gif"),
    (b"GIF89a", "image/gif"),
)

_SUPPORTED = {"image/png", "image/jpeg", "image/gif", "image/webp"}


class ImageParser:
    def __init__(self, gemini: GeminiClient):
        self.gemini = gemini

    def parse(
        self,
        image_bytes: bytes,
        filename: str,
        mime_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        meta: Dict[str, Any] = {
            "source_file": filename,
            "size_bytes": len(image_bytes),
        }

        if not image_bytes:
            return {"_meta": meta, "error": "Empty image file"}

        # Signature-based, not name-based: we know the magic bytes of every
        # format we support, so a non-match means the file genuinely isn't
        # one — reject it rather than spending an API call on a PDF or an
        # HTML error page that happens to be named .png.
        resolved = self._resolve_mime(image_bytes)
        meta["mime_type"] = resolved or (mime_type or "unknown")
        meta["declared_mime_type"] = mime_type

        if resolved is None:
            logger.warning(
                "[Image] %s — content is not a supported image (declared %s)",
                filename, mime_type,
            )
            return {
                "_meta": meta,
                "error": (
                    "File content is not a supported image "
                    f"(declared: {mime_type or 'none'}); "
                    "expected PNG, JPEG, GIF or WEBP"
                ),
            }

        if len(image_bytes) > MAX_IMAGE_BYTES:
            logger.warning(
                "[Image] %s — %.1f MB exceeds the %.0f MB inline limit",
                filename,
                len(image_bytes) / 1024 / 1024,
                MAX_IMAGE_BYTES / 1024 / 1024,
            )
            return {
                "_meta": meta,
                "error": (
                    f"Image too large for inline extraction "
                    f"({len(image_bytes) / 1024 / 1024:.1f} MB)"
                ),
            }

        logger.info(
            "[Image] %s — sending %.0f KB as %s to Gemini",
            filename, len(image_bytes) / 1024, resolved,
        )

        try:
            raw = self.gemini.extract_from_image_bytes(
                image_bytes=image_bytes,
                mime_type=resolved,
                system_prompt=GENERIC_JSON_PROMPT,
            )
        except ImagesNotPermitted as exc:
            # The proxy refuses image input. Fall back to local OCR and let
            # the LLM build the JSON from the extracted TEXT instead — the
            # content is recovered rather than lost.
            ocr_result = self._ocr_fallback(image_bytes, filename, resolved)
            if ocr_result is not None:
                return ocr_result
            # Proxy policy, not a problem with this file. Record it and move
            # on: raising would retry and dead-letter every image in the
            # bucket for a reason no retry can fix.
            # The client already logged the policy block once; keep the
            # per-file line at debug so thousands of images don't flood logs.
            logger.debug(
                "[Image] %s — image input not permitted; placeholder record",
                filename,
            )
            return {
                "_meta": {
                    "source_file": filename,
                    "size_bytes": len(image_bytes),
                    "mime_type": resolved,
                },
                "error": "image_input_not_permitted",
                "detail": (
                    "The LLM proxy rejected image input for this model "
                    "(403: image is not allowed). Re-run with --force once "
                    "image parts are enabled to extract this file."
                ),
                "proxy_message": str(exc)[:300],
            }

        try:
            result = json.loads(self._strip_fences(raw))
        except Exception:
            logger.warning("[Image] Could not parse JSON for %s", filename)
            return {
                "raw_extraction": raw,
                "parse_error": True,
                "_meta": meta,
            }

        if not isinstance(result, dict):
            result = {"extraction": result}
        # _meta on success too — every other parser does this, and without it
        # image outputs carried no provenance at all.
        result["_meta"] = meta
        return result

    # ---------------------------------------------------------- helpers

    @staticmethod
    def _resolve_mime(data: bytes) -> Optional[str]:
        """Identify the image type from its magic bytes.

        Returns None when the content matches none of the supported
        formats — the declared type is never trusted on its own, because
        mislabeled files are common in email attachments and exports.
        """
        head = data[:12]
        for magic, mime in _MAGIC:
            if head.startswith(magic):
                return mime
        if head[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return "image/webp"
        return None

    def _ocr_fallback(self, image_bytes, filename, mime):
        """OCR the image locally, then have the LLM structure the text."""
        from utils.ocr import OCRUnavailable, image_to_text

        try:
            text, engine = image_to_text(image_bytes)
        except OCRUnavailable as exc:
            logger.warning("[Image] %s — no OCR fallback: %s", filename, exc)
            return None
        except ValueError as exc:
            logger.info("[Image] %s — OCR found no usable text (%s)", filename, exc)
            return {
                "_meta": {
                    "source_file": filename, "mime_type": mime,
                    "extraction_method": "ocr", "ocr_text_chars": 0,
                },
                "error": "no_readable_text",
                "detail": str(exc),
            }
        except Exception:
            logger.exception("[Image] %s — OCR failed", filename)
            return None

        logger.info(
            "[Image] %s — OCR (%s) produced %d chars; sending text to Gemini",
            filename, engine, len(text),
        )
        try:
            raw = self.gemini.extract_from_text(text, GENERIC_JSON_PROMPT)
        except Exception:
            logger.exception("[Image] %s — LLM call on OCR text failed", filename)
            return None

        try:
            result = json.loads(self._strip_fences(raw))
        except Exception:
            result = {"raw_extraction": raw, "parse_error": True}
        if not isinstance(result, dict):
            result = {"extraction": result}
        result["_meta"] = {
            "source_file": filename,
            "size_bytes": len(image_bytes),
            "mime_type": mime,
            "extraction_method": f"ocr:{engine}",
            "ocr_text_chars": len(text),
            "note": (
                "LLM image input is blocked by the proxy; text was recovered "
                "locally with OCR and structured by the LLM. Accuracy is "
                "lower than native image understanding."
            ),
        }
        return result

    @staticmethod
    def _strip_fences(raw: str) -> str:
        text = (raw or "").strip()
        if text.startswith("```"):
            text = text[3:]
            if text.lstrip().lower().startswith("json"):
                text = text.lstrip()[4:]
            text = text.rsplit("```", 1)[0]
        return text.strip()
