"""
parsers/pptx_parser.py

Extracts text (slide shapes, tables, speaker notes) from .pptx files via
python-pptx, then sends to Gemini for structured JSON extraction.
"""

import io
import json
import logging
from typing import Dict, Any, List

from pptx import Presentation

from utils.gemini_client import GeminiClient, GENERIC_JSON_PROMPT

logger = logging.getLogger(__name__)


class PPTXParser:
    def __init__(self, gemini: GeminiClient):
        self.gemini = gemini

    def parse(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        prs = Presentation(io.BytesIO(file_bytes))

        slide_texts: List[str] = []
        for idx, slide in enumerate(prs.slides, start=1):
            parts: List[str] = [f"--- SLIDE {idx} ---"]
            for shape in slide.shapes:
                if shape.has_text_frame and shape.text_frame.text.strip():
                    parts.append(shape.text_frame.text.strip())
                if getattr(shape, "has_table", False) and shape.has_table:
                    for row in shape.table.rows:
                        cells = [c.text.strip() for c in row.cells]
                        parts.append(" | ".join(cells))
            notes = getattr(slide, "notes_slide", None)
            if (
                slide.has_notes_slide
                and notes is not None
                and notes.notes_text_frame is not None
                and notes.notes_text_frame.text.strip()
            ):
                parts.append("[notes] " + notes.notes_text_frame.text.strip())
            slide_texts.append("\n".join(parts))

        combined = "\n\n".join(slide_texts)
        logger.info(
            "[PPTX] %s — %d slide(s), %d chars extracted",
            filename, len(slide_texts), len(combined),
        )

        if not combined.strip():
            return {
                "_meta": {"source_file": filename, "slide_count": len(slide_texts)},
                "error": "No extractable text in presentation",
            }

        raw = self.gemini.extract_from_text(combined, GENERIC_JSON_PROMPT)
        result = self._safe_parse_json(raw, filename)
        result["_meta"] = {
            "source_file": filename,
            "slide_count": len(slide_texts),
            "char_count": len(combined),
        }
        return result

    @staticmethod
    def _safe_parse_json(raw: str, label: str) -> Dict[str, Any]:
        try:
            return json.loads(raw.strip())
        except json.JSONDecodeError:
            logger.warning("[PPTX] Could not parse JSON for %s", label)
            return {"raw_extraction": raw, "parse_error": True}
