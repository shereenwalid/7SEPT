import io
import json
import logging
from typing import Dict, Any, List, Optional, Set

import pandas as pd
from openpyxl import load_workbook

from utils.gemini_client import (
    EXCEL_LAYOUT_PROMPT,
    GENERIC_JSON_PROMPT,
    GeminiClient,
)

logger = logging.getLogger(__name__)

# Safety valve: if a workbook has more non-empty cells than this, don't send
# it to Gemini cell-by-cell — fall back to a straight pandas table load.

MAX_CELLS_FOR_GEMINI = 50000
MAX_CHARS_FOR_GEMINI = 100000

class ExcelParser:
    def __init__(self, gemini: Optional[GeminiClient] = None,
                 max_cells_for_gemini: int = MAX_CELLS_FOR_GEMINI):
        self.gemini = gemini
        self.max_cells_for_gemini = max_cells_for_gemini


    def _extract_embedded_images(
        self, file_bytes: bytes, filename: str
    ) -> List[Dict[str, Any]]:
        """Pull images embedded in worksheets (pasted screenshots, scanned
        POs, signature images).

        Only cell VALUES were read before, so a sheet whose entire content
        is a pasted screenshot looked empty and was dropped — the document
        it contained was invisible to everything downstream.

        Returns [{sheet, name, data, mime}], newest openpyxl API first with
        a zip fallback (xlsx/xlsm/xlsb are all OPC zip packages).
        """
        images: List[Dict[str, Any]] = []
        lower = filename.lower()

        if lower.endswith((".xlsx", ".xlsm")):
            try:
                # read_only=True does not load drawings, so open normally.
                wb = load_workbook(io.BytesIO(file_bytes), data_only=True)
                for ws in wb.worksheets:
                    if ws.sheet_state != "visible":
                        continue
                    for img in getattr(ws, "_images", []) or []:
                        try:
                            data = img._data()
                        except Exception:
                            continue
                        if not data:
                            continue
                        images.append({
                            "sheet": ws.title,
                            "name": getattr(
                                getattr(img, "path", None), "name", None
                            ) or f"{ws.title}_image{len(images) + 1}",
                            "data": data,
                            "mime": self._image_mime(data),
                        })
                wb.close()
            except Exception as exc:
                logger.warning(
                    "[Excel] Could not read embedded images from %s: %s",
                    filename, exc,
                )

        if not images:
            # Fallback: every OPC package stores media under xl/media/.
            # Loses the sheet association but not the image.
            try:
                import zipfile
                with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
                    for n in sorted(zf.namelist()):
                        if not n.lower().startswith("xl/media/"):
                            continue
                        data = zf.read(n)
                        if data:
                            images.append({
                                "sheet": None,
                                "name": n.rsplit("/", 1)[-1],
                                "data": data,
                                "mime": self._image_mime(data),
                            })
            except Exception:
                pass

        if images:
            logger.info(
                "[Excel] %s — found %d embedded image(s): %s",
                filename, len(images),
                ", ".join(f"{i['name']}({i['sheet'] or '?'})" for i in images[:5]),
            )
        return images

    @staticmethod
    def _image_mime(data: bytes) -> str:
        if data.startswith(b"\x89PNG\r\n\x1a\n"):
            return "image/png"
        if data.startswith(b"\xff\xd8\xff"):
            return "image/jpeg"
        if data.startswith(b"GIF8"):
            return "image/gif"
        if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
            return "image/webp"
        return "application/octet-stream"

    def _parse_embedded_images(
        self, file_bytes: bytes, filename: str
    ) -> List[Dict[str, Any]]:
        """Extract embedded images and run each through Gemini."""
        from utils.gemini_client import ImagesNotPermitted

        found = self._extract_embedded_images(file_bytes, filename)
        if not found:
            return []

        max_images = 10
        results: List[Dict[str, Any]] = []
        for img in found[:max_images]:
            entry = {"sheet": img["sheet"], "image": img["name"]}
            if img["mime"] == "application/octet-stream":
                entry["error"] = "unrecognised image format"
                results.append(entry)
                continue
            if self.gemini is None:
                entry["error"] = "no LLM configured"
                results.append(entry)
                continue
            try:
                raw = self.gemini.extract_from_image_bytes(
                    image_bytes=img["data"],
                    mime_type=img["mime"],
                    system_prompt=GENERIC_JSON_PROMPT,
                )
                entry["extraction"] = self._safe_json(raw)
            except ImagesNotPermitted as exc:
                # Proxy blocks image input — recover the text locally.
                ocr = self._ocr_embedded(img["data"])
                if ocr is not None:
                    entry["extraction"] = ocr[0]
                    entry["extraction_method"] = f"ocr:{ocr[1]}"
                    entry["ocr_text_chars"] = ocr[2]
                else:
                    entry["error"] = "image_input_not_permitted"
                    entry["detail"] = str(exc)[:200]
            except Exception as exc:
                logger.warning(
                    "[Excel] Embedded image %s in %s failed: %s",
                    img["name"], filename, exc,
                )
                entry["error"] = str(exc)[:200]
            results.append(entry)

        if len(found) > max_images:
            results.append({
                "note": f"{len(found) - max_images} further image(s) not parsed"
            })
        return results

    def _ocr_embedded(self, data: bytes):
        """OCR an embedded image, then structure the text with the LLM.
        Returns (extraction, engine, char_count) or None."""
        from utils.ocr import image_to_text

        try:
            text, engine = image_to_text(data)
        except Exception as exc:
            logger.info("[Excel] OCR fallback unavailable/empty: %s", exc)
            return None
        try:
            raw = self.gemini.extract_from_text(text, GENERIC_JSON_PROMPT)
        except Exception:
            logger.exception("[Excel] LLM call on OCR text failed")
            return None
        return self._safe_json(raw), engine, len(text)

    @staticmethod
    def _safe_json(raw: str) -> Any:
        text = (raw or "").strip()
        if text.startswith("```"):
            text = text.strip("`")
            if text.lower().startswith("json"):
                text = text[4:]
        try:
            return json.loads(text.strip())
        except Exception:
            return {"raw_extraction": raw, "parse_error": True}

    def parse(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """Parse a workbook, including any images embedded in its sheets."""
        result = self._parse_cells(file_bytes, filename)

        # Screenshots pasted into a sheet (POs, signed forms, email grabs)
        # carry real content that cell parsing cannot see. Attach them to
        # whatever the cell parse produced.
        try:
            images = self._parse_embedded_images(file_bytes, filename)
        except Exception as exc:
            logger.warning(
                "[Excel] Embedded image handling failed for %s: %s",
                filename, exc,
            )
            images = []

        if images:
            result.setdefault("_meta", {})["embedded_image_count"] = len(images)
            result["embedded_images"] = images
            # A workbook whose only content was a screenshot previously came
            # back as "Empty or unreadable" — it isn't, now that we can see
            # the image.
            if result.get("error") == "Empty or unreadable file":
                result.pop("error", None)
                result["_meta"]["note"] = (
                    "No cell data; content came from embedded image(s)."
                )
        return result

    def _parse_cells(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """
        Parse an Excel file and return a structured JSON summary.
        All extracted data (tables and forms) is returned as JSON for
        the caller to save to GCS — no BigQuery insertion is performed.
        """
        # openpyxl (used by _dump_cells) cannot open legacy .xls at all —
        # previously these came back as "Empty or unreadable". Same for
        # binary .xlsb. CSV isn't a workbook — load it directly. .xlsm
        # works fine on the normal openpyxl path.
        lower = filename.lower()
        if lower.endswith(".csv"):
            logger.info("[Excel] %s — CSV, using direct pandas load", filename)
            return self._csv_load(file_bytes, filename)
        if lower.endswith((".xls", ".xlsb")):
            logger.info(
                "[Excel] %s — legacy/binary workbook, using direct pandas load",
                filename,
            )
            return self._fallback_table_load(file_bytes, filename)

        cells = self._dump_cells(file_bytes, filename)
        if not cells:
            logger.warning("[Excel] Empty or unreadable file: %s", filename)
            return {
                "_meta": {"source_file": filename, "rows_inserted": 0},
                "error": "Empty or unreadable file",
            }

        if self.gemini is None or len(cells) > self.max_cells_for_gemini:
            logger.info(
                "[Excel] %s — %d cells, skipping Gemini (no client or over "
                "%d-cell threshold), falling back to direct table load",
                filename, len(cells), self.max_cells_for_gemini,
            )
            return self._fallback_table_load(file_bytes, filename)
        
        try:
            structure = self._classify_with_gemini(cells, filename)
            return self._route_blocks(structure, filename)

        except Exception as exc:
            logger.warning(
                "[Excel] %s - Gemini failed (%s), using fallback load",
                filename,
                exc,
            )

            return self._fallback_table_load(
                file_bytes,
                filename,
            )

        # structure = self._classify_with_gemini(cells, filename)
        # return self._route_blocks(structure, filename)


    def _dump_cells(self, file_bytes: bytes, filename: str) -> List[str]:
        """
        Read every non-empty cell from every sheet and represent it as a
        position-tagged line: "[sheet_name] R<row>C<col>: <value>".

        This makes no assumption about where data starts, whether columns
        line up across sheets, or whether a sheet holds one table or five.
        """
        try:
            wb = load_workbook(io.BytesIO(file_bytes), data_only=True, read_only=True)
        except Exception as exc:
            logger.exception("[Excel] Failed to open workbook %s: %s", filename, exc)
            return []

        lines: List[str] = []
        skipped: List[str] = []
        for sheet in wb.worksheets:
            # Excel marks sheets "visible", "hidden", or "veryHidden".
            # Hidden sheets are usually working/scratch data the user does
            # not consider part of the document — extracting them produced
            # rows that appear nowhere in the visible workbook.
            if sheet.sheet_state != "visible":
                skipped.append(f"{sheet.title}({sheet.sheet_state})")
                continue
            for row in sheet.iter_rows():
                for cell in row:
                    value = cell.value
                    if value is None:
                        continue
                    text = str(value).strip()
                    if not text:
                        continue
                    lines.append(f"[{sheet.title}] R{cell.row}C{cell.column}: {text}")
        if skipped:
            logger.info(
                "[Excel] %s — skipped %d hidden sheet(s): %s",
                filename, len(skipped), ", ".join(skipped),
            )
        wb.close()
        return lines


    # def _classify_with_gemini(self, cells: List[str], filename: str) -> Dict[str, Any]:
    #     dump_text = "\n".join(cells)
    #     raw = self.gemini.extract_from_text(dump_text, EXCEL_LAYOUT_PROMPT)
    #     return self._safe_parse_json(raw, filename)

    def _classify_with_gemini(self, cells: List[str], filename: str) -> Dict[str, Any]:
        dump_text = "\n".join(cells)

        logger.info(
            "[Excel] %s - %s cells, %s chars sent to Gemini",
            filename,
            len(cells),
            len(dump_text),
        )

        if len(dump_text) > MAX_CHARS_FOR_GEMINI:
            logger.info(
                "[Excel] %s - dump too large (%s chars), using fallback load",
                filename,
                len(dump_text),
            )
            raise ValueError("EXCEL_TOO_LARGE_FOR_GEMINI")

        raw = self.gemini.extract_from_text(
            dump_text,
            EXCEL_LAYOUT_PROMPT,
        )

        return self._safe_parse_json(raw, filename)


    def _route_blocks(self, structure: Dict[str, Any], filename: str) -> Dict[str, Any]:
        sheets = structure.get("sheets", [])
        if not sheets and "raw_extraction" in structure:
            return {
                "_meta": {"source_file": filename},
                "error": "Could not interpret sheet structure",
                "raw_extraction": structure["raw_extraction"],
            }

        form_blocks: List[Dict[str, Any]] = []
        table_blocks: List[Dict[str, Any]] = []

        for sheet in sheets:
            sheet_name = sheet.get("sheet_name", "Sheet1")
            for block in sheet.get("blocks", []):
                layout = block.get("layout")

                if layout == "table" and block.get("rows"):
                    table_blocks.append({
                        "sheet_name": sheet_name,
                        "title": block.get("title"),
                        "rows": block.get("rows"),
                        "notes": block.get("notes"),
                    })

                elif layout == "form" and block.get("fields"):
                    form_blocks.append({
                        "sheet_name": sheet_name,
                        "title": block.get("title"),
                        "fields": block.get("fields"),
                        "notes": block.get("notes"),
                    })

                else:
                    logger.warning(
                        "[Excel] %s — block on sheet '%s' had layout=%r with no "
                        "usable data, skipping",
                        filename, sheet_name, layout,
                    )

        summary: Dict[str, Any] = {
            "_meta": {
                "source_file": filename,
                "form_block_count": len(form_blocks),
                "table_block_count": len(table_blocks),
                "confidence": structure.get("confidence"),
            }
        }
        if form_blocks:
            summary["forms"] = form_blocks
        if table_blocks:
            summary["tables"] = table_blocks

        logger.info(
            "[Excel] %s — %d form block(s), %d table block(s) written as JSON",
            filename, len(form_blocks), len(table_blocks),
        )
        return summary


    def _visible_sheet_names(
        self, file_bytes: bytes, filename: str
    ) -> Optional[Set[str]]:
        """Return the set of VISIBLE sheet names, or None if visibility
        can't be determined (caller then falls back to reading all sheets).

        Each format stores visibility differently:
          .xlsx/.xlsm  openpyxl exposes ws.sheet_state
          .xls         xlrd exposes sheet.visibility (0 = visible)
          .xlsb        pyxlsb exposes no visibility API, so read the
                       BrtBundleSh records out of xl/workbook.bin directly
        """
        lower = filename.lower()
        try:
            if lower.endswith((".xlsx", ".xlsm")):
                wb = load_workbook(
                    io.BytesIO(file_bytes), read_only=True, data_only=True
                )
                names = {
                    ws.title for ws in wb.worksheets
                    if ws.sheet_state == "visible"
                }
                wb.close()
                return names

            if lower.endswith(".xls"):
                import xlrd
                book = xlrd.open_workbook(file_contents=file_bytes)
                # visibility: 0 = visible, 1 = hidden, 2 = "very hidden"
                return {
                    sh.name for sh in book.sheets()
                    if getattr(sh, "visibility", 0) == 0
                }

            if lower.endswith(".xlsb"):
                return self._xlsb_visible_sheets(file_bytes)
        except Exception as exc:
            logger.warning(
                "[Excel] Could not determine sheet visibility for %s (%s) — "
                "processing all sheets", filename, exc,
            )
        return None

    @staticmethod
    def _xlsb_visible_sheets(file_bytes: bytes) -> Optional[Set[str]]:
        """Parse sheet visibility from an .xlsb workbook part.

        .xlsb is a zip whose xl/workbook.bin holds BrtBundleSh records
        (record type 156): [4-byte state][4-byte id][4-byte rel-id len +
        UTF-16LE][4-byte name len + UTF-16LE]. state 0 = visible.
        Records use variable-length ids and sizes, so walk the stream.
        """
        import zipfile
        import struct

        with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
            if "xl/workbook.bin" not in zf.namelist():
                return None
            data = zf.read("xl/workbook.bin")

        visible: Set[str] = set()
        pos, n = 0, len(data)
        while pos < n:
            # Variable-length record id (1-2 bytes, high bit = continue)
            b = data[pos]; pos += 1
            rec_id = b & 0x7F
            if b & 0x80:
                if pos >= n:
                    break
                b2 = data[pos]; pos += 1
                rec_id |= (b2 & 0x7F) << 7
            # Variable-length record size (1-4 bytes)
            size, shift = 0, 0
            for _ in range(4):
                if pos >= n:
                    return visible or None
                b = data[pos]; pos += 1
                size |= (b & 0x7F) << shift
                if not (b & 0x80):
                    break
                shift += 7
            payload = data[pos: pos + size]
            pos += size

            if rec_id == 156 and len(payload) >= 12:   # BrtBundleSh
                state = struct.unpack_from("<I", payload, 0)[0]
                off = 8
                rel_len = struct.unpack_from("<I", payload, off)[0]
                off += 4
                if rel_len != 0xFFFFFFFF:
                    off += rel_len * 2
                if off + 4 > len(payload):
                    continue
                name_len = struct.unpack_from("<I", payload, off)[0]
                off += 4
                name = payload[off: off + name_len * 2].decode(
                    "utf-16-le", errors="replace"
                )
                if state == 0:      # 0 visible, 1 hidden, 2 very hidden
                    visible.add(name)
        return visible or None

    def _fallback_table_load(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        # openpyxl only reads .xlsx/.xlsm; legacy .xls needs xlrd, binary
        # .xlsb needs pyxlsb.
        lower = filename.lower()
        if lower.endswith(".xls"):
            engine = "xlrd"
        elif lower.endswith(".xlsb"):
            engine = "pyxlsb"
        else:
            engine = "openpyxl"
        try:
            sheets = pd.read_excel(io.BytesIO(file_bytes), sheet_name=None, engine=engine)
        except Exception as exc:
            logger.exception("[Excel] Fallback load failed for %s: %s", filename, exc)
            return {
                "_meta": {"source_file": filename},
                "error": "Empty or unreadable file",
            }

        visible = self._visible_sheet_names(file_bytes, filename)
        hidden_skipped: List[str] = []
        table_blocks: List[Dict[str, Any]] = []

        for sheet_name, df in sheets.items():
            if visible is not None and sheet_name not in visible:
                hidden_skipped.append(sheet_name)
                continue
            if df is None or df.empty:
                continue
            df = self._clean_dataframe(df, filename, sheet_name, title=None)
            table_blocks.append({
                "sheet_name": sheet_name,
                "title": None,
                "rows": self._json_safe_records(df),
                "notes": None,
            })

        summary: Dict[str, Any] = {
            "_meta": {
                "source_file": filename,
                "table_block_count": len(table_blocks),
                "parse_strategy": "fallback_direct_load",
                "hidden_sheets_skipped": hidden_skipped,
                "sheet_visibility_known": visible is not None,
            }
        }
        if hidden_skipped:
            logger.info(
                "[Excel] %s — skipped %d hidden sheet(s): %s",
                filename, len(hidden_skipped), ", ".join(hidden_skipped),
            )
        if table_blocks:
            summary["tables"] = table_blocks

        logger.info(
            "[Excel] %s — fallback load produced %d table block(s) as JSON",
            filename, len(table_blocks),
        )
        return summary


    def _csv_load(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """Load a CSV into the same table-blocks shape as workbook output."""
        try:
            df = pd.read_csv(
                io.BytesIO(file_bytes),
                sep=None, engine="python",       # sniff , ; \t delimiters
                encoding_errors="replace",
            )
        except Exception as exc:
            logger.exception("[Excel] CSV load failed for %s: %s", filename, exc)
            return {
                "_meta": {"source_file": filename},
                "error": "Empty or unreadable file",
            }

        if df.empty:
            return {"_meta": {"source_file": filename}, "error": "Empty file"}

        df = self._clean_dataframe(df, filename, "csv", title=None)
        return {
            "_meta": {
                "source_file": filename,
                "table_block_count": 1,
                "parse_strategy": "pandas_csv",
            },
            "tables": [{
                "sheet_name": "csv",
                "title": None,
                "rows": self._json_safe_records(df),
                "notes": None,
            }],
        }

    # Values that are placeholders rather than data.
    _JUNK_VALUES = {
        "", "nan", "none", "null", "n/a", "na", "-", "--", "?", "#n/a",
        "#value!", "#ref!", "#div/0!",
    }

    @classmethod
    def _is_junk_value(cls, v) -> bool:
        """True for nulls, blank strings and spreadsheet placeholder text."""
        if v is None:
            return True
        try:
            if pd.isna(v):
                return True
        except (TypeError, ValueError):
            pass
        if isinstance(v, str):
            return v.strip().lower() in cls._JUNK_VALUES
        return False

    @classmethod
    def _is_noise_series(cls, s) -> bool:
        """True if a column holds no information: only nulls, junk text, or
        zeros. Used for unnamed spacer columns only."""
        for v in s:
            if cls._is_junk_value(v):
                continue
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                try:
                    if float(v) == 0.0:
                        continue
                except (TypeError, ValueError):
                    pass
            elif isinstance(v, str) and v.strip() in ("0", "0.0"):
                continue
            return False   # found real content
        return True

    @staticmethod
    def _json_safe_records(df: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        df.to_dict(orient="records") yields pd.Timestamp / NaT / NaN values
        that json.dumps cannot serialize (this is what made large workbooks
        'disappear' — the upload crashed after a successful parse).
        Round-tripping through pandas' own JSON encoder converts
        Timestamps to ISO strings and NaN/NaT to null.

        Null keys are then dropped from each record: a spreadsheet row only
        fills a few of the sheet's columns, so keeping every empty one
        ("unnamed_1": null, ...) bloats the JSON and adds no information.
        Records left with nothing but _source_* metadata are dropped too.
        """
        import json as _json
        raw = _json.loads(df.to_json(orient="records", date_format="iso"))

        cleaned: List[Dict[str, Any]] = []
        for rec in raw:
            trimmed = {}
            for k, v in rec.items():
                if ExcelParser._is_junk_value(v):
                    continue          # null / "nan" / "n/a" / blank
                # A leftover spacer key with a zero carries no information
                # ({"unnamed:_1": 0}); a zero under a real header does.
                if str(k).startswith("unnamed"):
                    try:
                        if float(v) == 0.0:
                            continue
                    except (TypeError, ValueError):
                        pass
                trimmed[k] = v
            # Anything left that isn't bookkeeping?
            if any(not k.startswith("_") for k in trimmed):
                cleaned.append(trimmed)
        return cleaned

    @classmethod
    def _clean_dataframe(
        cls, df: pd.DataFrame, filename: str,
        sheet_name: Optional[str], title: Optional[str]
    ) -> pd.DataFrame:
        # Treat whitespace-only strings and the literal "nan"/"none"/"null"
        # text (common in exported sheets) as genuinely empty, so the
        # emptiness checks below actually catch them.
        df = df.replace(
            r"^\s*(?:nan|none|null|n/?a|-{1,2})?\s*$", pd.NA, regex=True
        )

        df = df.dropna(how="all").dropna(axis=1, how="all")

        df.columns = [
            "col_" + str(c).strip().lower().replace(" ", "_").replace("-", "_")
            if str(c) and str(c)[0].isdigit()
            else str(c).strip().lower().replace(" ", "_").replace("-", "_")
            for c in df.columns
        ]

        # pandas names header-less columns "Unnamed: 0", "Unnamed: 1"...
        # (they become "unnamed:_0" above). These are spacer columns from
        # the spreadsheet layout — drop them when they carry no data.
        # Spacer columns: pandas names header-less columns "Unnamed: N".
        # Dropping only fully-empty ones left junk like {"unnamed:_1": 0}
        # behind, so also drop unnamed columns that carry nothing but
        # zeros / junk placeholders. A zero in a NAMED column (qty: 0) is
        # real data and is never touched.
        # Any column carrying no information at all — only nulls, junk
        # placeholders, or zeros — is dropped, named or not. This catches
        # spreadsheet spacer columns ("unnamed:_1") and stray headers that
        # are really data cells ("col_0x17.80"), both of which showed up as
        # {"col": 0} noise in every record.
        # Trade-off: a genuinely all-zero column (e.g. a discount column
        # that is 0 on every row) is also dropped. That carries no
        # information either, but note it is a deliberate choice — a column
        # with a single non-zero value anywhere is always kept.
        drop_cols = [c for c in df.columns if cls._is_noise_series(df[c])]
        if drop_cols:
            logger.debug("[Excel] Dropping %d spacer column(s)", len(drop_cols))
            df = df.drop(columns=drop_cols)

        # Deduplicate column names so records don't silently lose fields.
        seen: Dict[str, int] = {}
        new_cols = []
        for c in df.columns:
            if c in seen:
                seen[c] += 1
                new_cols.append(f"{c}_{seen[c]}")
            else:
                seen[c] = 0
                new_cols.append(c)
        df.columns = new_cols

        # Re-check emptiness after the replacements above, then drop any row
        # that is entirely empty (this runs BEFORE metadata columns are
        # added, so metadata can't keep a blank row alive).
        df = df.dropna(how="all")

        df["_source_file"] = filename
        if sheet_name:
            df["_source_sheet"] = sheet_name
        if title:
            df["_block_title"] = title

        # NOTE: previously this was `df[col].astype(str)`, which turned NaN
        # into the literal string "nan" — polluting output with fake values
        # that survived every emptiness check downstream. Keep nulls null.
        for col in df.select_dtypes(include=["object", "string"]).columns:
            df[col] = df[col].apply(
                lambda v: v if pd.isna(v) else str(v).strip()
            )

        return df


    @staticmethod
    def _safe_parse_json(raw: str, label: str) -> Dict[str, Any]:
        import json
        try:
            clean = raw.strip()
            if clean.startswith("```"):
                clean = clean.lstrip("`")
                if clean.lower().startswith("json"):
                    clean = clean[4:]
                clean = clean.rstrip("`").strip()
            return json.loads(clean)
        except json.JSONDecodeError:
            logger.warning("[Excel] Could not parse Gemini JSON for %s", label)
            return {"raw_extraction": raw, "parse_error": True}
