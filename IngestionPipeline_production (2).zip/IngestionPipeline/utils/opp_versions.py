"""
utils/opp_versions.py — OPP folder parsing and version ranking.

Input folders look like:
    8461_OPP-0007724692_1114                      (original, no date)
    Modified-File/8461_OPP-0007724692_05082026_1114   (modified, dated)

Outputs are consolidated per OPP id:
    processed_files/OPP-0007724692/<file>              <- newest version
    processed_files/OPP-0007724692/archive/<file>      <- every older version

DATE FORMAT: the 8-digit stamp is read as DDMMYYYY (05082026 = 5 Aug 2026),
matching Irish/European convention. If these stamps are actually MMDDYYYY,
set date_format="MMDDYYYY" — getting this wrong silently picks the wrong
"newest" version, so it is worth confirming against a known folder.
"""

import logging
import re
from datetime import datetime
from typing import Dict, List, NamedTuple, Optional, Tuple

logger = logging.getLogger(__name__)

# 8461_OPP-0007724692_05082026_1114  ->  batch, opp, date, time
_DATED = re.compile(
    r"^(?P<batch>\d+)_(?P<opp>OPP-\d+)_(?P<date>\d{8})_(?P<time>\d{4})$",
    re.IGNORECASE,
)
# 8461_OPP-0007724692_1114  ->  batch, opp, time (no date = original)
_UNDATED = re.compile(
    r"^(?P<batch>\d+)_(?P<opp>OPP-\d+)_(?P<time>\d{4})$",
    re.IGNORECASE,
)
# Fallback: any folder containing an OPP id
_ANY_OPP = re.compile(r"(?P<opp>OPP-\d+)", re.IGNORECASE)


class OppFolder(NamedTuple):
    opp_id: str                  # "OPP-0007724692"
    batch: Optional[str]         # "8461"
    stamp: Optional[datetime]    # None for undated originals
    raw: str                     # original folder segment

    @property
    def version_key(self) -> Tuple[int, float, str]:
        """Sortable. Undated originals rank oldest (they predate the
        Modified-File versions). Ties broken by raw name for determinism."""
        if self.stamp is None:
            return (0, 0.0, self.raw)
        return (1, self.stamp.timestamp(), self.raw)

    @property
    def suffix(self) -> str:
        """Version tag appended to archived filenames so different versions
        (and different batches) never collide in archive/."""
        parts = [p for p in (self.batch, self._stamp_str()) if p]
        return "_".join(parts) if parts else self.raw

    def _stamp_str(self) -> Optional[str]:
        return self.stamp.strftime("%d%m%Y_%H%M") if self.stamp else None


def parse_opp_folder(
    segment: str, date_format: str = "DDMMYYYY"
) -> Optional[OppFolder]:
    """Parse one folder segment. Returns None if it isn't an OPP folder."""
    seg = segment.strip("/")
    fmt = "%d%m%Y" if date_format.upper() == "DDMMYYYY" else "%m%d%Y"

    md = _DATED.match(seg)
    if md:
        try:
            stamp = datetime.strptime(
                md.group("date") + md.group("time"), fmt + "%H%M"
            )
        except ValueError:
            logger.warning(
                "Folder %s has an unparseable date stamp — treating as undated",
                seg,
            )
            stamp = None
        return OppFolder(
            md.group("opp").upper(), md.group("batch"), stamp, seg
        )

    mu = _UNDATED.match(seg)
    if mu:
        return OppFolder(mu.group("opp").upper(), mu.group("batch"), None, seg)

    ma = _ANY_OPP.search(seg)
    if ma:
        # Unexpected shape but identifiable — keep it rather than dropping it.
        logger.info("Folder %s: non-standard shape, treated as undated", seg)
        return OppFolder(ma.group("opp").upper(), None, None, seg)

    return None


def find_opp_in_path(
    blob_name: str, date_format: str = "DDMMYYYY"
) -> Optional[Tuple[OppFolder, str]]:
    """Locate the OPP folder inside a blob path.

    Returns (OppFolder, relative_path_within_that_folder), or None.
    e.g. ".../Modified-File/8461_OPP-1_05082026_1114/docs/spec.pdf"
         -> (OppFolder(...), "docs/spec.pdf")
    """
    parts = blob_name.split("/")
    for idx, seg in enumerate(parts[:-1]):
        folder = parse_opp_folder(seg, date_format)
        if folder:
            return folder, "/".join(parts[idx + 1:])
    return None


def rank_versions(
    folders: List[OppFolder],
) -> Dict[str, List[OppFolder]]:
    """Group folders by OPP id, newest first."""
    grouped: Dict[str, List[OppFolder]] = {}
    for f in folders:
        grouped.setdefault(f.opp_id, []).append(f)
    for opp, items in grouped.items():
        items.sort(key=lambda f: f.version_key, reverse=True)
    return grouped
